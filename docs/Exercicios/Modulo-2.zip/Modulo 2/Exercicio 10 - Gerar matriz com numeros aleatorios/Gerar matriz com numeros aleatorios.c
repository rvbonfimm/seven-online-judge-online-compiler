#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define TAM 10

// Matriz
float matriz[TAM][TAM];
int main() {

int i,j; //declara��o das variaveis inteiras usadas pelos loops
float a;

srand(time(NULL)); //fun��o que gera numero aleatorios diferentes em cada execu��o

for(i=0;i<TAM;i++) 
{
 for(j=0;j<TAM;j++) 
  {
   a=rand(); //gera um n�mero aleat�rio para a
   matriz[i][j]=a; //coloca os numeros na matriz
  } 
}
for(i=0;i<TAM;i++) //loop para percorrer a matriz em i
{
for(j=0;j<TAM;j++) //loop para percorrer a matriz em j
 {
 printf("%.2f  ",matriz[i][j]); //imprime a matriz com precis�o de dois digitos
 }
printf("\n"); //pula linha
}

system("PAUSE");
return 0;
}
