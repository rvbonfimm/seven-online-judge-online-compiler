#include <stdio.h>
#include <stdlib.h>
#define JOGOS 50
#define N 6
/* Matriz de mais de uma dimens�o*/

int main() {
	int matriz[JOGOS][N], k , j;
	
	for(k = 0; k < JOGOS; k++)
		for(j = 0; j < N; j++)
		matriz[k][j]=rand()%60+1; //numero aleatorio de 1 a 60
		
	for(k = 0; k < JOGOS; k++){
		printf("Combinacao %2d:     ", k+1);
		for(j = 0; j < N; j++)
		printf("%2d    ", matriz[k][j]);
		printf("\n");
	}
	system("PAUSE");
	return 0;
}
