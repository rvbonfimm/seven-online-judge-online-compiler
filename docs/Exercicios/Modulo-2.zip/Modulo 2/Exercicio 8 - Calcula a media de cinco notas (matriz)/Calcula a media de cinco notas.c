#include <stdio.h>
#include <stdlib.h>

/* Calcula a media de cinco notas utilizando matriz */

int main(int argc, char *argv[]) {
	int notas[5];
	int i;
	float media = 0.0;
	
	for(i = 0; i < 5; i++){
		printf("Digite a nota do aluno %d: ", i+1);
		scanf("%d", &notas[i]);
		media += notas[i];
	}
	media /= 5.0;
	printf("Media das notas: %.2f\n", media);
	system("PAUSE");
	return 0;
}
