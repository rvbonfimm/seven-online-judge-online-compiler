#include <stdio.h>
#include <stdlib.h>

/* Chamando uma fun��o */

int main() {
	int n;
	printf("Digite um numero: ");
	scanf("%d", &n);
	printf("O quadrado do numero e %d. \n", (n*n));
	system("PAUSE");
	return 0;
}
