#include <stdio.h>
#include <stdlib.h>

/* Fun��o que gera n�meros aleat�rios*/
unsigned rand(void); //prot�tipo

int main() {
	int i;
	for(i = 0; i < 5; i++)
		printf("%d\n", rand());
	system("PAUSE");
	return 0;
}

unsigned rand()
{
	static unsigned semente = 1;
	semente = (semente * 25173 + 13849)%65536; //formula magica
	return semente;
}
