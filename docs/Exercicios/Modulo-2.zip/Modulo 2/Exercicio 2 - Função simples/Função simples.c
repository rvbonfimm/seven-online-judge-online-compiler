#include <stdio.h>
#include <stdlib.h>

/* Fun��o simples */

float celsius(float); // prot�tipo ou declara��o da fun��o

int main() {
	float c, f;
	printf("Digite a temperatura em graus Fahrenheit: ");
	scanf("%f", &f);
	c = celsius(f);	//chamando a fun��o
	
	printf("Celsius = %.2f\n", c);
	
	system("PAUSE");
	return 0;
}

// Defini��o da fun��o
float celsius(float fahr)
{
	float c;
	c = (fahr - 32.0) * 5.0/9.0;
	return c;
}
