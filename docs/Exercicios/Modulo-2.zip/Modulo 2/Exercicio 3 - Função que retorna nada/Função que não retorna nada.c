#include <stdio.h>
#include <stdlib.h>

/* Fun��o que n�o retorna nada, tipo void*/

void linha(int); //prot�tipo

int main() {
	linha(20);
	printf("\xDB um programa em c \xDB\n");
	linha(20);
	system("PAUSE");
	return 0;
}

//linha() - desenha uma linha s�lida na tela, n caracteres

void linha(int n)
{
	int j;
	for(j = 1; j <= n; j++)
	printf("\xDB");
	printf("\n");
}
