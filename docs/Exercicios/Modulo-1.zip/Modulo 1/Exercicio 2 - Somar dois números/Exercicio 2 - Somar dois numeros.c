#include <stdio.h>
#include <stdlib.h>

// Soma de dois n�meros

int main(int argc, char *argv[]) {
	int x, y, soma;
	scanf ("%d", &x);
	scanf ("%d", &y);
	soma = x + y;
	printf ("O resultado da soma e: %d" , soma);
	return 0;
}
