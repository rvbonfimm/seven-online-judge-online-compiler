#include <stdio.h>
#include <stdlib.h>

/* Ponteiros vari�veis */

void reajusta7(float *, float *); //prototipo
int main() {
	float val_preco, val_reaj;

		printf("Insira o preco atual: ");
		scanf("%f", &val_preco);
		reajusta7(&val_preco, &val_reaj); //enviando endere�os
		printf("\nO preco novo e: %.2f\n", val_preco);
		printf("O aumento foi de: %.2f\n", val_reaj);
		
	system("PAUSE");
	return 0;
}

void reajusta7(float *preco, float *reajuste){
	*reajuste = *preco * 0.07;
	*preco *= 1.07;
}
