#include <stdio.h>
#include <stdlib.h>

/* Ponteiros Constantes*/

int main() {
	int v,r,h;
	
	printf("Endereco de v = %p\n", &v);
	printf("Endereco de r = %p\n", &r);
	printf("Endereco de h = %p\n", &h);	
	return 0;
}
