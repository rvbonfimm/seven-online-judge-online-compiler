#include <stdio.h>
#include <stdlib.h>

int main()
{ int i,tam;
  int *pv;
  //definir tamanho
  printf("entre tamanho:");
  scanf("%d",&tam);
  // alocar mem�ria
  pv=(int *)malloc(tam *sizeof(int));
  //inicializar vetor e imprimir
  for(i=0;i<=tam;i++)
  { pv[i]=i;
    printf("%d\n",pv[i]);
  }  
  
  system("PAUSE");
  free(pv);	
  return 0;
}
