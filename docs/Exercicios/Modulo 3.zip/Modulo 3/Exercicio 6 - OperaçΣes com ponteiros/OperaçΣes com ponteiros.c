#include <stdio.h>
#include <stdlib.h>

/* Opera��es com ponteiros */

void troca(int *a, int *b){
	int temp;
	temp = *a;
	*a = *b;
	*b = temp;
	printf("x = %d \ny = %d\n", *a, *b);
}

int main() {

	int x , y;

	troca(&x, &y);
	
	system("PAUSE");
	return 0;
}
