#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* Canverter hexa para bin�rio */

int palavra();

int main() 
{
	int t, j, num, bit;
	unsigned int mask;

	    t = palavra();
		//1 no bit mais significativo e 0 (zero) nos outros
		mask = pow(2, t-1);
		printf("\nDigite um numero em hexadecimal: ");
		scanf("%x",&num);
		printf("Binario de %04x e: ", num);
		
		for(j = 0; j < t; j++)
		{
			bit = (mask& num) ? 1 : 0;
			printf("%d",bit);
			if(((j+1) % 8) == 0) //tra�o entre bytes
				printf("--");
			mask >>= 1;
		}
		system("PAUSE");
	return 0;
}

int palavra(){
	unsigned int n = ~0; //todos os bits ligados
	int i;
	for(i = 0; n; i++) //enquanto n n�o for zero
		n <<= 1;
		return i;
}

